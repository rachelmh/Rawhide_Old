var MathjaxScript=document.createElement("script");
MathjaxScript.type="text/javascript";
MathjaxScript.src="https://cdn.mathjax.org/mathjax/latest/MathJax.js?config=TeX-AMS-MML_HTMLorMML";
document.head.appendChild(MathjaxScript);
