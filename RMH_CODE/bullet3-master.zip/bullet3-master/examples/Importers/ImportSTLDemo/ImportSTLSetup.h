#ifndef IMPORT_STL_SETUP_H
#define IMPORT_STL_SETUP_H

class CommonExampleInterface* ImportSTLCreateFunc(struct CommonExampleOptions& options);

#endif  //IMPORT_OBJ_SETUP_H
