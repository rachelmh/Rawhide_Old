#ifndef INVERTED_PENDULUM_PD_CONTROL_H
#define INVERTED_PENDULUM_PD_CONTROL_H

class CommonExampleInterface* InvertedPendulumPDControlCreateFunc(struct CommonExampleOptions& options);

#endif  //INVERTED_PENDULUM_PD_CONTROL_H
