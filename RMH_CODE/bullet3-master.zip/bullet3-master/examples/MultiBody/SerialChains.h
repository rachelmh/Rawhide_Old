
#ifndef MULTI_BODY_CONSTRAINT_SOLVERS_DEMO_H
#define MULTI_BODY_CONSTRAINT_SOLVERS_DEMO_H

class CommonExampleInterface* SerialChainsCreateFunc(struct CommonExampleOptions& options);

#endif  //MULTI_BODY_CONSTRAINT_SOLVERS_DEMO_H
